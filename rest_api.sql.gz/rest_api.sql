-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Час створення: Лис 26 2019 р., 08:33
-- Версія сервера: 10.1.36-MariaDB
-- Версія PHP: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База даних: `rest_api`
--

-- --------------------------------------------------------

--
-- Структура таблиці `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `category`
--

INSERT INTO `category` (`id`, `parent_id`, `name`, `description`) VALUES
(1, 0, 'Планшеты', 'Описание категории \"Планшеты\" Описание категории \"Планшеты\" Описание категории \"Планшеты\" Описание категории \"Планшеты\" Описание категории \"Планшеты\" Описание категории \"Планшеты\" Описание категории \"Планшеты\" Описание категории \"Планшеты\" Описание категории \"Планшеты\" Описание категории \"Планшеты\" '),
(2, 0, 'Мобильные телефоны', 'Описание категории \"Мобильные телефоны\" Описание категории \"Мобильные телефоны\" Описание категории \"Мобильные телефоны\" Описание категории \"Мобильные телефоны\" Описание категории \"Мобильные телефоны\" Описание категории \"Мобильные телефоны\" Описание категории \"Мобильные телефоны\" Описание категории \"Мобильные телефоны\" Описание категории \"Мобильные телефоны\" '),
(3, 2, 'Смартфоны', 'Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны Смартфоны '),
(4, 2, 'Кнопочные телефоны', 'Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны Кнопочные телефоны '),
(5, 3, '-1', NULL),
(6, 3, 'Смартфоны LG', 'Все смартфоны LG'),
(7, 0, '123', NULL),
(8, 0, '123', NULL);

-- --------------------------------------------------------

--
-- Структура таблиці `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `name` varchar(100) NOT NULL,
  `description` text,
  `model` varchar(32) DEFAULT NULL,
  `sku` varchar(32) DEFAULT NULL,
  `price` float NOT NULL,
  `currency_id` int(11) NOT NULL,
  `in_stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `product`
--

INSERT INTO `product` (`id`, `created_at`, `name`, `description`, `model`, `sku`, `price`, `currency_id`, `in_stock`) VALUES
(1, '2019-11-23 19:48:45', '66', NULL, 'Readmi 6A', '12345567890', 66, 1, 99),
(2, '2019-11-23 19:51:19', '66', NULL, 'Readmi Note 8', '0987654321', 66, 1, 199),
(3, '2019-11-25 11:55:29', '66', NULL, NULL, NULL, 66, 0, 0),
(4, '2019-11-25 11:55:58', '66', NULL, NULL, NULL, 66, 0, 0),
(5, '2019-11-25 11:56:28', '66', NULL, NULL, NULL, 66, 0, 0),
(6, '2019-11-25 11:56:38', '66', NULL, NULL, NULL, 66, 0, 0),
(7, '2019-11-25 22:03:05', '66', NULL, NULL, NULL, 66, 0, 0),
(8, '2019-11-25 22:12:07', '66', NULL, NULL, NULL, 66, 0, 0),
(9, '2019-11-25 22:13:10', '66', NULL, NULL, NULL, 66, 0, 0),
(10, '2019-11-25 22:13:30', '66', NULL, NULL, NULL, 66, 0, 0),
(11, '2019-11-25 22:13:46', '66', NULL, NULL, NULL, 66, 0, 0),
(12, '2019-11-25 22:13:50', '66', NULL, NULL, NULL, 66, 0, 0),
(13, '2019-11-25 22:14:06', '66', NULL, NULL, NULL, 66, 0, 0),
(14, '2019-11-25 22:14:32', '66', NULL, NULL, NULL, 66, 0, 0),
(15, '2019-11-25 22:14:35', '66', NULL, NULL, NULL, 66, 0, 0),
(16, '2019-11-25 22:15:25', '66', NULL, NULL, NULL, 66, 0, 0),
(17, '2019-11-25 22:16:07', '66', NULL, NULL, NULL, 66, 0, 0),
(18, '2019-11-25 22:16:18', '66', NULL, NULL, NULL, 66, 0, 0),
(19, '2019-11-25 22:16:39', '66', NULL, NULL, NULL, 66, 0, 0),
(20, '2019-11-25 22:17:48', '66', NULL, NULL, NULL, 66, 0, 0),
(21, '2019-11-25 22:18:02', '66', NULL, NULL, NULL, 66, 0, 0),
(22, '2019-11-25 22:18:53', '66', NULL, NULL, NULL, 66, 0, 0),
(23, '2019-11-25 22:23:29', '66', NULL, NULL, NULL, 66, 0, 0),
(24, '2019-11-25 22:25:27', '66', NULL, NULL, NULL, 66, 0, 0),
(26, '2019-11-25 22:27:21', '66', NULL, NULL, NULL, 66, 0, 0),
(27, '2019-11-25 22:27:24', '66', NULL, NULL, NULL, 66, 0, 0),
(28, '2019-11-25 22:29:15', '77', NULL, NULL, NULL, 77, 0, 0),
(29, '2019-11-25 22:29:40', '66', NULL, NULL, NULL, 66, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблиці `product_category`
--

CREATE TABLE `product_category` (
  `product_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп даних таблиці `product_category`
--

INSERT INTO `product_category` (`product_id`, `category_id`) VALUES
(1, 1),
(1, 3),
(2, 1),
(2, 3),
(3, 3),
(28, 3),
(29, 3);

--
-- Індекси збережених таблиць
--

--
-- Індекси таблиці `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Індекси таблиці `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Індекси таблиці `product_category`
--
ALTER TABLE `product_category`
  ADD UNIQUE KEY `product_id` (`product_id`,`category_id`);

--
-- AUTO_INCREMENT для збережених таблиць
--

--
-- AUTO_INCREMENT для таблиці `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблиці `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
